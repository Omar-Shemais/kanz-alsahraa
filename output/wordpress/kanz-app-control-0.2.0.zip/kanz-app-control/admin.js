/* global wp, kanzAdmin */
(() => {
  'use strict';
  const json = document.getElementById('kanz-json');
  if (!json) return;
  const container = document.getElementById('kanz-sections');
  const error = document.getElementById('kanz-error');
  let config;
  let textDirty = false;
  const expandedFields = new Set();
  const message = (value) => { error.textContent = value; };
  function validate(value) {
    if (!value || !Array.isArray(value.HorizonLayout) || !Array.isArray(value.TabBar) || !value.TabBar.length || !value.Setting || Array.isArray(value.Setting) || typeof value.Setting !== 'object') {
      throw new Error('الملف يحتاج HorizonLayout وTabBar وSetting صحيحة.');
    }
    return value;
  }
  function sync() { json.value = JSON.stringify(config, null, 2); textDirty = false; }
  function apply() {
    try { config = validate(JSON.parse(json.value)); textDirty = false; render(); message(''); }
    catch (_) { message('JSON غير صالح أو تنقصه إعدادات التطبيق. لم يتغير المحرر.'); }
  }
  function change(action) {
    if (textDirty) { message('طبّق تعديلات JSON على المحرر أولاً؛ لن يتم استبدال نصك.'); return; }
    if (!config) { message('استورد ملف إعدادات التطبيق أولاً.'); return; }
    try { action(); sync(); render(); message(''); }
    catch (failure) { message(failure.message || 'راجع القيمة المدخلة.'); }
  }
  function button(label, action, parent) {
    const item = document.createElement('button');
    item.type = 'button'; item.className = 'button'; item.textContent = label;
    item.style.margin = '4px'; item.addEventListener('click', action); parent.append(item);
  }
  function field(label, value, action, parent) {
    const wrapper = document.createElement('label'); wrapper.textContent = `${label}: `;
    wrapper.style.display = 'block'; wrapper.style.margin = '8px';
    const input = document.createElement('input'); input.type = 'text'; input.value = value ?? '';
    input.addEventListener('change', () => change(() => action(input.value)));
    wrapper.append(input); parent.append(wrapper);
  }
  function media(action) {
    if (!window.wp || !wp.media) { message('تعذر فتح مكتبة الوسائط.'); return; }
    const picker = wp.media({ title: 'اختر صورة البانر', multiple: false, library: { type: 'image' } });
    picker.on('select', () => {
      const item = picker.state().get('selection').first().toJSON();
      change(() => action(item.url));
    }); picker.open();
  }
  function categoryField(label, value, action, parent) {
    const categories = typeof kanzAdmin !== 'undefined' ? kanzAdmin.categories : [];
    if (!categories || !categories.length) { field(label, value, action, parent); return; }
    const wrapper = document.createElement('label'); wrapper.textContent = `${label}: `;
    wrapper.style.cssText = 'display:block;margin:8px';
    const select = document.createElement('select');
    const options = [{ id: '', name: 'بدون تصنيف محدد' }, ...categories];
    if (value != null && String(value) && !options.some((item) => item.id === String(value))) {
      options.push({ id: String(value), name: `التصنيف الحالي #${value} (غير موجود في القائمة)` });
    }
    options.forEach((item) => {
      const option = document.createElement('option'); option.value = item.id;
      option.textContent = item.id ? `${item.name} — #${item.id}` : item.name;
      select.append(option);
    });
    select.value = String(value ?? '');
    select.addEventListener('change', () => change(() => action(select.value)));
    wrapper.append(select); parent.append(wrapper);
  }
  function render() {
    container.replaceChildren();
    if (!config) return;
    renderUpdates();
    renderAllFields();
    config.HorizonLayout.forEach((section, index) => {
      const card = document.createElement('div');
      card.style.cssText = 'border:1px solid #ccc;padding:12px;margin:12px 0;background:white';
      const title = document.createElement('h3'); title.textContent = `${index + 1}. ${section.name || section.layout}`; card.append(title);
      button('↑', () => change(() => { if (index > 0) [config.HorizonLayout[index - 1], config.HorizonLayout[index]] = [section, config.HorizonLayout[index - 1]]; }), card);
      button('↓', () => change(() => { if (index + 1 < config.HorizonLayout.length) [config.HorizonLayout[index + 1], config.HorizonLayout[index]] = [section, config.HorizonLayout[index + 1]]; }), card);
      button('حذف القسم', () => { if (window.confirm('حذف القسم من المسودة؟')) change(() => config.HorizonLayout.splice(index, 1)); }, card);
      field('الاسم', section.name, (value) => { section.name = value; }, card);
      if (!['logo', 'bannerImage', 'luxurySaleBanner'].includes(section.layout)) {
        categoryField('تصنيف المنتجات', section.category, (value) => { section.category = value; }, card);
        field('عدد المنتجات', section.limit ?? 12, (value) => {
          const count = Number(value);
          if (!Number.isInteger(count) || count < 1 || count > 100) throw new Error('عدد المنتجات من 1 إلى 100.');
          section.limit = count;
        }, card);
        const sort = document.createElement('select');
        [['', 'ترتيب المتجر'], ['popularity', 'الأكثر مبيعاً'], ['date', 'الأحدث'], ['rating', 'الأعلى تقييماً'], ['price', 'حسب السعر']].forEach(([key, label]) => {
          const option = document.createElement('option'); option.value = key; option.textContent = label; sort.append(option);
        });
        sort.value = section.orderby || '';
        sort.addEventListener('change', () => change(() => {
          if (sort.value) { section.orderby = sort.value; section.order = 'desc'; }
          else { delete section.orderby; delete section.order; }
        })); card.append(sort);
      }
      if (['bannerImage', 'luxurySaleBanner'].includes(section.layout)) {
        (section.items || []).forEach((item, itemIndex) => {
          const row = document.createElement('div'); row.style.borderTop = '1px solid #ddd';
          field('رابط الصورة', item.image, (value) => { item.image = value; }, row);
          categoryField('التصنيف عند الضغط', item.category, (value) => { item.category = value; }, row);
          button('اختيار الصورة', () => media((url) => { item.image = url; }), row);
          button('حذف العنصر', () => change(() => section.items.splice(itemIndex, 1)), row);
          button('↑', () => change(() => { if (itemIndex > 0) [section.items[itemIndex - 1], section.items[itemIndex]] = [item, section.items[itemIndex - 1]]; }), row);
          button('↓', () => change(() => { if (itemIndex + 1 < section.items.length) [section.items[itemIndex + 1], section.items[itemIndex]] = [item, section.items[itemIndex + 1]]; }), row);
          card.append(row);
        });
        button('إضافة عنصر', () => change(() => { (section.items ||= []).push({ image: '', category: '', radius: 9 }); }), card);
      }
      container.append(card);
    });
  }
  function renderUpdates() {
    const updates = document.getElementById('kanz-updates'); if (!updates) return;
    updates.replaceChildren();
    ['android', 'ios'].forEach((platform) => {
      const setting = config.KanzControl?.updates?.[platform] || { enabled: false, minimumBuild: 0 };
      const card = document.createElement('div');
      const title = document.createElement('h3'); title.textContent = platform === 'android' ? 'Android' : 'iPhone'; card.append(title);
      const set = (key, value) => {
        config.KanzControl ||= {}; config.KanzControl.updates ||= {};
        config.KanzControl.updates[platform] = { ...setting, [key]: value };
      };
      field('الحد الأدنى لرقم البناء', setting.minimumBuild, (value) => {
        const minimum = Number(value);
        if (!Number.isInteger(minimum) || minimum < 0 || minimum > 2147483647) throw new Error('أدخل رقم بناء صحيحاً.');
        set('minimumBuild', minimum);
      }, card);
      const label = document.createElement('label');
      const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.checked = setting.enabled === true;
      checkbox.addEventListener('change', () => change(() => {
        if (checkbox.checked && (setting.minimumBuild < 1 || !window.confirm('هل الإصدار المطلوب متاح فعلياً في المتجر؟ إجبار إصدار غير متاح يمنع العملاء من استخدام التطبيق.'))) return;
        set('enabled', checkbox.checked);
      })); label.append(checkbox, 'إجبار تحديث الإصدارات الأقدم'); card.append(label); updates.append(card);
    });
  }
  function renderAllFields() {
    const root = document.getElementById('kanz-all-fields'); if (!root) return;
    root.replaceChildren();
    const labels = {
      Setting: 'إعدادات المظهر', HorizonLayout: 'أقسام الصفحة الرئيسية', TabBar: 'شريط التنقل',
      MainColor: 'اللون الرئيسي', FontFamily: 'خط النصوص', FontHeader: 'خط العناوين',
      name: 'الاسم', image: 'رابط الصورة', category: 'رقم التصنيف', title: 'العنوان',
      items: 'العناصر', itemsWeb: 'عناصر نسخة الويب', layout: 'نوع العرض', limit: 'عدد المنتجات',
      showSearch: 'إظهار البحث', showLogo: 'إظهار الشعار', showMenu: 'إظهار القائمة',
      autoPlay: 'تشغيل البانرات تلقائياً', height: 'الارتفاع', radius: 'استدارة الزوايا',
      KanzControl: 'التحكم في التطبيق', updates: 'التحديثات', minimumBuild: 'الحد الأدنى لرقم البناء',
      enabled: 'مفعّل', PrivacyPoliciesPageUrlOrId: 'رابط سياسة الخصوصية',
    };
    function walk(parent, key, value, target, path) {
      const label = labels[key] || String(key);
      if (value !== null && typeof value === 'object') {
        const details = document.createElement('details'); details.open = expandedFields.has(path);
        const summary = document.createElement('summary'); summary.textContent = label; details.append(summary);
        details.addEventListener('toggle', () => {
          if (details.open) expandedFields.add(path); else expandedFields.delete(path);
        });
        Object.entries(value).forEach(([childKey, child]) => walk(value, childKey, child, details, `${path}/${childKey}`));
        target.append(details); return;
      }
      const wrapper = document.createElement('label'); wrapper.style.cssText = 'display:block;margin:8px 18px';
      wrapper.append(`${label}: `);
      const input = document.createElement(typeof value === 'string' && value.length > 100 ? 'textarea' : 'input');
      if (typeof value === 'boolean') { input.type = 'checkbox'; input.checked = value; }
      else if (typeof value === 'number') { input.type = 'number'; input.step = 'any'; input.value = value; }
      else { input.value = value === null ? '' : String(value); }
      input.addEventListener('change', () => change(() => {
        if (typeof value === 'boolean') parent[key] = input.checked;
        else if (typeof value === 'number') {
          if (!input.value.trim() || !Number.isFinite(Number(input.value))) throw new Error('أدخل رقماً صحيحاً.');
          parent[key] = Number(input.value);
        } else if (value === null) {
          throw new Error('القيمة الفارغة null تحتاج تحرير JSON المتقدم لتغيير نوعها.');
        } else parent[key] = input.value;
      }));
      wrapper.append(input); target.append(wrapper);
    }
    Object.entries(config).forEach(([key, value]) => walk(config, key, value, root, key));
  }
  json.addEventListener('input', () => { textDirty = true; });
  document.getElementById('kanz-apply').addEventListener('click', apply);
  document.getElementById('kanz-import').addEventListener('change', async (event) => {
    const file = event.target.files[0]; if (!file) return;
    if (file.size > 1048576) { message('الملف أكبر من 1 ميجابايت.'); return; }
    try {
      const value = validate(JSON.parse(await file.text()));
      if (json.value && !window.confirm('استبدال المسودة بالملف المستورد؟')) return;
      config = value; sync(); render(); message('تم الاستيراد إلى المسودة فقط. راجعها قبل النشر.');
    } catch (_) { message('تعذر قراءة ملف إعدادات صالح.'); }
  });
  document.getElementById('kanz-add-banner').addEventListener('click', () => change(() => config.HorizonLayout.push({ layout: 'bannerImage', design: 'static', items: [] })));
  document.getElementById('kanz-add-category').addEventListener('click', () => change(() => config.HorizonLayout.push({ layout: 'oneAndHalfColumn', name: 'قسم جديد', category: '', limit: 12, rows: 1 })));
  document.getElementById('kanz-form').addEventListener('submit', (event) => {
    try {
      const publishing = validate(JSON.parse(json.value));
      if (Object.values(publishing.KanzControl?.updates || {}).some((item) => item.enabled === true) && !document.getElementById('kanz-confirm-updates')?.checked) {
        event.preventDefault(); message('أكد توفر الإصدار المطلوب في المتجر قبل نشر التحديث الإجباري.'); return;
      }
      if (!window.confirm('نشر هذه الإعدادات للتطبيق؟')) event.preventDefault();
    } catch (_) { event.preventDefault(); message('أصلح JSON قبل النشر.'); }
  });
  document.getElementById('kanz-export')?.addEventListener('click', () => {
    try {
      const value = validate(JSON.parse(json.value));
      const url = URL.createObjectURL(new Blob([JSON.stringify(value, null, 2)], { type: 'application/json' }));
      const link = document.createElement('a'); link.href = url; link.download = 'config_ar.json'; link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (_) { message('صحح الملف قبل تحميله.'); }
  });
  if (json.value) apply();
})();
