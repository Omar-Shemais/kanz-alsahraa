<?php
defined('ABSPATH') || exit;

function kanz_notification_payload($title, $body) {
    if (!is_string($title) || !is_string($body) || trim($title) === '' || trim($body) === '' ||
        strlen($title) > 240 || strlen($body) > 2400 || strip_tags($title) !== $title || strip_tags($body) !== $body) {
        return new WP_Error('invalid_message', 'أدخل عنواناً ونصاً قصيرين دون HTML.');
    }
    // Marketing only. Never use customer_ID topics for private order data.
    return array('message' => array('topic' => 'all-notifications',
        'notification' => array('title' => trim($title), 'body' => trim($body))));
}

function kanz_notification_credentials() {
    if (!defined('KANZ_FCM_SERVICE_ACCOUNT_FILE') || !function_exists('openssl_sign')) {
        return new WP_Error('not_configured', 'الإشعارات غير مربوطة بخدمة Firebase على الخادم.');
    }
    $path = realpath(KANZ_FCM_SERVICE_ACCOUNT_FILE);
    $root = realpath(isset($_SERVER['DOCUMENT_ROOT']) ? $_SERVER['DOCUMENT_ROOT'] : dirname(ABSPATH));
    // File must be outside the publicly served tree, not a Media upload.
    if (!$path || !$root || strpos(str_replace('\\', '/', $path), rtrim(str_replace('\\', '/', $root), '/') . '/') === 0 ||
        !is_file($path) || !is_readable($path) || filesize($path) > 65536) {
        return new WP_Error('unsafe_credentials', 'يلزم ملف Firebase خاص خارج مجلد الويب، يضبطه مسؤول الاستضافة.');
    }
    $account = json_decode(file_get_contents($path), true);
    if (!is_array($account) || empty($account['project_id']) || empty($account['client_email']) || empty($account['private_key']) ||
        !is_string($account['project_id']) || !is_string($account['client_email']) ||
        !preg_match('/^[a-z][a-z0-9-]{4,62}$/', $account['project_id']) ||
        !filter_var($account['client_email'], FILTER_VALIDATE_EMAIL) || !is_string($account['private_key'])) {
        return new WP_Error('invalid_credentials', 'تعذر قراءة إعداد Firebase الخاص.');
    }
    return $account;
}

function kanz_notification_send($payload) {
    $account = kanz_notification_credentials();
    if (is_wp_error($account)) { return $account; }
    $encode = function ($value) { return rtrim(strtr(base64_encode($value), '+/', '-_'), '='); };
    $now = time();
    $jwt = $encode(wp_json_encode(array('alg' => 'RS256', 'typ' => 'JWT'))) . '.' .
        $encode(wp_json_encode(array('iss' => $account['client_email'], 'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
            'aud' => 'https://oauth2.googleapis.com/token', 'iat' => $now, 'exp' => $now + 3600)));
    $signature = '';
    if (!openssl_sign($jwt, $signature, $account['private_key'], OPENSSL_ALGO_SHA256)) {
        return new WP_Error('signing_failed', 'تعذر اعتماد اتصال Firebase.');
    }
    // Fixed Google endpoints; never trust token_uri or URLs from an upload.
    $auth = wp_remote_post('https://oauth2.googleapis.com/token', array('timeout' => 20, 'redirection' => 0, 'sslverify' => true,
        'body' => array('grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer', 'assertion' => $jwt . '.' . $encode($signature))));
    if (is_wp_error($auth) || wp_remote_retrieve_response_code($auth) !== 200) {
        return new WP_Error('auth_failed', 'تعذر الاتصال بـFirebase. لم يُرسل الإشعار.');
    }
    $token = json_decode(wp_remote_retrieve_body($auth), true);
    if (!is_array($token) || empty($token['access_token']) || !is_string($token['access_token']) || preg_match('/[\r\n]/', $token['access_token'])) {
        return new WP_Error('auth_invalid', 'استجابة Firebase غير صالحة. لم يُرسل الإشعار.');
    }
    $result = wp_remote_post('https://fcm.googleapis.com/v1/projects/' . $account['project_id'] . '/messages:send', array(
        'timeout' => 20, 'redirection' => 0, 'sslverify' => true,
        'headers' => array('Authorization' => 'Bearer ' . $token['access_token'], 'Content-Type' => 'application/json'),
        'body' => wp_json_encode($payload)));
    if (is_wp_error($result)) {
        // A timeout may occur AFTER FCM accepts a message. Never retry silently.
        return new WP_Error('send_uncertain', 'نتيجة الإرسال غير مؤكدة. لا تعاود الإرسال قبل مراجعتها لتجنب التكرار.');
    }
    $accepted = json_decode(wp_remote_retrieve_body($result), true);
    if (wp_remote_retrieve_response_code($result) !== 200 || !is_array($accepted) || empty($accepted['name'])) {
        return new WP_Error('send_rejected', 'لم يؤكد Firebase قبول الرسالة. راجع إعداد المشروع.');
    }
    return true; // Accepted by FCM, not proof of delivery to every device.
}

add_action('admin_post_kanz_send_notification', function () {
    if (!current_user_can('manage_options')) { wp_die('غير مصرح', '', array('response' => 403)); }
    check_admin_referer('kanz_send_notification');
    if (empty($_POST['confirm_broadcast'])) { wp_die('راجع الجمهور وأكد الإرسال أولاً.'); }
    $title = isset($_POST['notification_title']) ? wp_unslash($_POST['notification_title']) : '';
    $body = isset($_POST['notification_body']) ? wp_unslash($_POST['notification_body']) : '';
    $payload = kanz_notification_payload($title, $body);
    if (is_wp_error($payload)) { wp_die(esc_html($payload->get_error_message())); }
    $credentials = kanz_notification_credentials();
    if (is_wp_error($credentials)) { wp_die(esc_html($credentials->get_error_message())); }
    $request_id = isset($_POST['request_id']) ? wp_unslash($_POST['request_id']) : '';
    if (!is_string($request_id) || !preg_match('/^[a-f0-9-]{36}$/i', $request_id)) { wp_die('معرف الإرسال غير صالح.'); }
    if (!add_option('kanz_notification_lock', time(), '', false)) { wp_die('هناك إرسال جارٍ. لا تكرر الرسالة.'); }
    $history = get_option('kanz_notification_history', array());
    foreach ($history as $entry) {
        if ($entry['id'] === $request_id || $entry['time'] > time() - 60) {
            delete_option('kanz_notification_lock'); wp_die('تمت معالجة الطلب أو جرت محاولة إرسال خلال الدقيقة الماضية. لا تكرر الرسالة.');
        }
    }
    // Record BEFORE sending. Killed processes do not silently resend on reload.
    $entry = array('id' => $request_id, 'time' => time(), 'status' => 'pending', 'title' => $title);
    array_unshift($history, $entry);
    $history = array_slice($history, 0, 50);
    if (!update_option('kanz_notification_history', $history, false)) {
        delete_option('kanz_notification_lock'); wp_die('تعذر تسجيل الإرسال. لم تُرسل الرسالة.');
    }
    $result = kanz_notification_send($payload);
    $history[0]['status'] = is_wp_error($result) ? $result->get_error_code() : 'accepted';
    update_option('kanz_notification_history', $history, false);
    delete_option('kanz_notification_lock');
    if (is_wp_error($result)) { wp_die(esc_html($result->get_error_message())); }
    wp_safe_redirect(admin_url('admin.php?page=kanz-app-control&notification=accepted'));
    exit;
});

function kanz_notification_page_section() {
    $ready = !is_wp_error(kanz_notification_credentials());
    ?>
    <h2>إشعارات عامة</h2>
    <p>للعروض والأخبار العامة فقط. لا تكتب بيانات طلب أو هاتف أو أي بيانات عميل؛ الجمهور هو المشترك في all-notifications.</p>
    <?php if (!$ready) { ?><p><strong>الإرسال معطل: يلزم إعداد Firebase خاص على الخادم خارج مجلد الويب.</strong></p><?php } ?>
    <?php if (isset($_GET['notification']) && $_GET['notification'] === 'accepted') { ?><p>قبل Firebase الرسالة. هذا لا يضمن وصولها لكل جهاز.</p><?php } ?>
    <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
      <input type="hidden" name="action" value="kanz_send_notification">
      <input type="hidden" name="request_id" value="<?php echo esc_attr(wp_generate_uuid4()); ?>">
      <?php wp_nonce_field('kanz_send_notification'); ?>
      <p><label>العنوان <input required name="notification_title" maxlength="80"></label></p>
      <p><label>النص<br><textarea required name="notification_body" maxlength="800" rows="4" cols="60"></textarea></label></p>
      <p><label><input required type="checkbox" name="confirm_broadcast" value="1">راجعت النص وأوافق على إرساله كإشعار عام، دون بيانات خاصة.</label></p>
      <button type="submit" class="button button-primary" <?php disabled(!$ready); ?>>إرسال إشعار عام</button>
    </form>
    <h3>سجل محاولات الإرسال</h3>
    <?php foreach (get_option('kanz_notification_history', array()) as $entry) { ?>
      <p><?php echo esc_html(gmdate('c', $entry['time']) . ' — ' . $entry['title'] . ' — ' . $entry['status']); ?></p>
    <?php } ?>
    <?php
}
